package com.neobank.model;

import com.neobank.model.enums.RolUsuario;
import io.micronaut.data.annotation.*;
import io.micronaut.data.model.naming.NamingStrategies;
import lombok.*;

@MappedEntity(
        value = "usuarios",
        namingStrategy = NamingStrategies.UnderScoreSeparatedLowerCase.class
)
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(callSuper = false)
public class Usuario extends Persona {

    @Id
    @GeneratedValue(GeneratedValue.Type.AUTO)
    private Long id;

    private String username;
    private String password;

    @Builder.Default
    private RolUsuario rol = RolUsuario.CAJERO;

    private boolean activo = true;
}