package com.neobank.model;

import com.neobank.model.enums.EstadoCliente;
import io.micronaut.data.annotation.*;
import io.micronaut.data.model.naming.NamingStrategies;
import lombok.*;

@MappedEntity(
        value = "clientes",
        namingStrategy = NamingStrategies.UnderScoreSeparatedLowerCase.class
)
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(callSuper = false)
public class Cliente extends Persona {

    @Id
    @GeneratedValue(GeneratedValue.Type.AUTO)
    private Long id;

    private String direccion;

    @Builder.Default
    private EstadoCliente estado = EstadoCliente.ACTIVO;
}