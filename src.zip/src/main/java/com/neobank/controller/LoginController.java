package com.neobank.controller;

import com.neobank.ApplicationContextProvider;
import com.neobank.model.Usuario;
import com.neobank.service.UsuarioService;
import jakarta.inject.Singleton;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import java.util.Optional;

@Singleton
public class LoginController {

    @FXML private TextField txtUsuario;
    @FXML private PasswordField txtPassword;
    @FXML private Label lblError;

    private UsuarioService usuarioService;

    @FXML
    public void initialize() {
        usuarioService = ApplicationContextProvider
                .getBean(UsuarioService.class);
    }

    @FXML
    private void handleLogin() {
        String username = txtUsuario.getText().trim();
        String password = txtPassword.getText().trim();

        if (username.isEmpty() || password.isEmpty()) {
            mostrarError("⚠ Completa todos los campos");
            return;
        }

        Optional<Usuario> usuario = usuarioService
                .login(username, password);

        if (usuario.isPresent()) {
            lblError.setStyle(
                    "-fx-text-fill: #66bb6a; -fx-font-size: 12px;"
            );
            lblError.setText(
                    "✔ Bienvenido, " + usuario.get().getNombre()
            );
        } else {
            mostrarError("✖ Usuario o contraseña incorrectos");
        }
    }

    private void mostrarError(String mensaje) {
        lblError.setStyle(
                "-fx-text-fill: #ef5350; -fx-font-size: 12px;"
        );
        lblError.setText(mensaje);
    }
}